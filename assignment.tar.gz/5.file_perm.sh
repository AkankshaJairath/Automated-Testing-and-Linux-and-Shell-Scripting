#!/bin/bash
# usage sh script.sh /var/log/sample.log

# Assign the argument to a variable
filename="$1"

# Check if the filename exists
if [ ! -e "$filename" ]; then
    echo "filename '$filename' does not exist."
    exit 2
fi

# Check read permission
if [ -r "$filename" ]; then
    echo "filename '$filename' has read permission."
else
    echo "filename '$filename' does not have read permission."
fi

# Check write permission
if [ -w "$filename" ]; then
    echo "filename '$filename' has write permission."
else
    echo "filename '$filename' does not have write permission."
fi

# Check execute permission
if [ -x "$filename" ]; then
    echo "filename '$filename' has execute permission."
else
    echo "filename '$filename' does not have execute permission."
fi

