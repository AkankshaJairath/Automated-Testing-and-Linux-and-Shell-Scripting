#!/bin/bash

# Get the username
username=$(whoami)

# Get the user ID
u_id=$(id -u)

# Get the group ID
g_id=$(id -g)

# Get the home directory
home_directory=$(echo $HOME)

# Get the shell being used
shell=$(echo $SHELL)

# Display the information
echo "User Information:"
echo "================="
echo "username:       $username"
echo "User ID:        $u_id"
echo "Group ID:       $g_id"
echo "Home Directory: $home_directory"
echo "Shell:          $shell"
