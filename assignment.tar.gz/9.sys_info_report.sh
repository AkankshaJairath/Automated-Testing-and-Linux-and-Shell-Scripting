#!/bin/bash

# Output file
analysis_file="system_report.txt"

# Get system uptime
uptime=$(uptime -p)

# Get memory_usage usage
memory_usage=$(free -h)

# Get CPU load
cpu_usage=$(top -bn1 | grep "load average:" | awk '{print $10 $11 $12}' | sed 's/,//g')

# Get disk usage
disk_usage=$(df /| grep /| awk '{print $5}')

# Get running processes of top 10 process w.r.t memory usage
processes=$(ps aux --sort=-%mem | head -n 10)

# Generate report
echo "System Information Report" > $analysis_file
echo "=========================" >> $analysis_file
echo "" >> $analysis_file

echo "System Uptime:" >> $analysis_file
echo "$UPTIME" >> $analysis_file
echo "" >> $analysis_file

echo "memory_usage Usage:" >> $analysis_file
echo "$memory_usage" >> $analysis_file
echo "" >> $analysis_file

echo "CPU Load:" >> $analysis_file
echo "$cpu_usage" >> $analysis_file
echo "" >> $analysis_file

echo "Disk Usage:" >> $analysis_file
echo "$disk_usage" >> $analysis_file
echo "" >> $analysis_file

echo "Top 10 Running processes (by memory_usage usage):" >> $analysis_file
echo "$processes" >> $analysis_file
echo "" >> $analysis_file

# Print message to indicate completion
echo "System report generated and saved to $analysis_file"
