#! /bin/bash

#mkdir used to create directory
# Creating 3 sub diretories under Projects Directory
sudo mkdir -p /home/user/projects/{project1,project2,project3}

# Creating Documents Directory
sudo mkdir /home/user/documents

# Creating Downloads Directory
sudo mkdir /home/user/downloads
