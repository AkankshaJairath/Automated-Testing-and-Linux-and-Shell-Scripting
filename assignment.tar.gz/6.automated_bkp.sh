#!/bin/bash

# Directories and filenames
source_directory="/home/user/documents"
bkp_directory="/home/user/backup"
bkp_file="documents_backup.tar.gz"

# Create a backup
tar -czf "$bkp_directory/$bkp_file" -C "$source_directory" .

# Check if the backup was successful
if [ $? -eq 0 ]; then
    echo "Backup was successful: $bkp_directory/$bkp_file"
else
    echo "Backup failed!, please check"
    exit 1
fi


#once this script ready, add an entry in crontab, below are the steps
#give execute permission to this file--> chmod +x <dir>/script.sh
#add an entry in crontab --> crontab -e --> 0 6 * * 1-5 <dir>/script.sh
