#!/bin/bash

# Function to perform the calculation
calculate() {
    local number1=$1
    local number2=$2
    local operation=$3

    case $operation in
        +) result=$(echo "$number1 + $number2" | bc);;
        -) result=$(echo "$number1 - $number2" | bc);;
        \*) result=$(echo "$number1 * $number2" | bc);;
        /) result=$(echo "scale=2; $number1 / $number2" | bc);;
        *) echo "Invalid operationerator"; exit 1;;
    esac
}

# Prompt the user for input
read -p "Enter the first number: " number1
read -p "Enter the second number: " number2
read -p "Enter the operationerator (+, -, *, /): " operation

# Perform the calculation
calculate "$number1" "$number2" "$operation"

# Display the result
echo "The result is: $result"
