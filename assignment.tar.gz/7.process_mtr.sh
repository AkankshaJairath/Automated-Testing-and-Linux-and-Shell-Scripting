
#!/bin/bash

# Process name to check
process_name="apache2"

# Log file
logfile="/var/log/process_monitor.log"

# Check if the process is running
if pgrep -x "$process_name" > /dev/null
then
    echo "$(date): $process_name is running." >> "$logfile"
else
    echo "$(date): $process_name is not running. Starting $process_name." >> "$logfile"

    # Start the process
    systemctl start "$process_name"

    # Log the result
    if [ $? -eq 0 ]; then
        echo "$(date): Successfully started $process_name." >> "$logfile"
    else
        echo "$(date): Failed to start $process_name." >> "$logfile"
    fi
fi
