#! /bib/bash

threshold_value=80
email="adminstration@admin.com" # Replace with the actual email address

# Check disk usage of the root filesystem
Disk_Usage=$(df / | grep / | awk '{ print $5 }' | sed 's/%//g')

# Check if usage is above the threshold_value
if [ "$Disk_Usage" -gt "$threshold_value" ]; then
    # Send an email alert
    subject="Disk Usage Alert: / is at ${Disk_Usage}%"
    message="Warning: The root filesystem (/) is at ${Disk_Usage}% capacity."
    echo "$message" | mail -s "$subject" "$email"
fi
