#!/bin/bash

# Assign the argument to a variable
filename="$1"

# Check if the filename exists
if [ ! -f "$filename" ]; then
    echo "filename '$filename' does not exist."
    exit 2
fi

# Count the number of no_of_lines, no_of_words, and characters
no_of_lines=$(wc -l < "$filename")
no_of_words=$(wc -w < "$filename")
no_of_characters=$(wc -m < "$filename")

# Display the counts
echo "filename: $filename"
echo "no_of_lines: $no_of_lines"
echo "no_of_words: $no_of_words"
echo "Characters: $no_of_characters"

