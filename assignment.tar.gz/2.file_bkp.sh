#!/bin/bash

# Assign the directory argument to a variable
src_directory="$1"

# Check if the directory exists
if [ ! -d "$src_directory" ]; then
    echo "Directory '$src_directory' does not exist."
    exit 2
fi

# Create the backup directory with a time
time=$(date +"%Y%m%d_%H%M%S")
bkp_directory="$src_directory/backup_$time"
mkdir -p "$bkp_directory"

# Copy all .txt files to the backup directory
find "$src_directory" -type f -iname "*.txt" -exec cp --preserve=times {} "$bkp_directory" \;
